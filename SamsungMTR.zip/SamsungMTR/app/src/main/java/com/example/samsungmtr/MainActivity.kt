package com.example.samsungmtr

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.material.bottomnavigation.BottomNavigationMenu

class MainActivity : AppCompatActivity() {

    private val firstFragment = FirstFragment()
    private val mapsFragment = MapsFragment()
    private val secondFragment = SecondFragment()




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        



    }
}